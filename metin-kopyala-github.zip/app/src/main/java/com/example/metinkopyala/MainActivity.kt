package com.example.metinkopyala

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        l.addView(TextView(this).apply {
            text = "1) Aşağıdaki düğmeyle Erişilebilirlik ayarlarını açın.\n" +
                "2) 'Metin Kopyala' servisini etkinleştirin.\n" +
                "3) Kopyalamak istediğiniz ekranda erişilebilirlik düğmesine (ekran altındaki simge) dokunun."
            textSize = 16f
        })
        l.addView(Button(this).apply {
            text = "Erişilebilirlik ayarlarını aç"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(l)
    }
}
