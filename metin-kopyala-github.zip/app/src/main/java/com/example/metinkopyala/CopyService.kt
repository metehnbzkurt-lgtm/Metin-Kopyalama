package com.example.metinkopyala

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Toast

class CopyService : AccessibilityService() {

    private var panel: View? = null
    private val wm by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }

    override fun onServiceConnected() {
        super.onServiceConnected()
        accessibilityButtonController.registerAccessibilityButtonCallback(
            object : AccessibilityButtonController.AccessibilityButtonCallback() {
                override fun onClicked(controller: AccessibilityButtonController) = toggle()
            }
        )
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun toggle() {
        if (panel != null) { close(); return }
        val items = LinkedHashSet<String>()
        rootInActiveWindow?.let { collect(it, items) }
        if (items.isEmpty()) {
            Toast.makeText(this, "Bu ekranda metin bulunamadı", Toast.LENGTH_SHORT).show()
            return
        }
        show(items.toList())
    }

    private fun collect(node: AccessibilityNodeInfo, out: MutableSet<String>) {
        node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { out.add(it) }
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { out.add(it) }
        for (i in 0 until node.childCount) node.getChild(i)?.let { collect(it, out) }
    }

    private fun copy(text: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("metin", text))
        Toast.makeText(this, "Kopyalandı", Toast.LENGTH_SHORT).show()
    }

    private fun show(items: List<String>) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F2FFFFFF"))
            setPadding(24, 24, 24, 24)
        }
        val list = ListView(this).apply {
            adapter = ArrayAdapter(this@CopyService, android.R.layout.simple_list_item_1, items)
            setOnItemClickListener { _, _, pos, _ -> copy(items[pos]); close() }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply {
            text = "Tümünü kopyala"
            setOnClickListener { copy(items.joinToString("\n")); close() }
        })
        root.addView(Button(this).apply {
            text = "Kapat"
            setOnClickListener { close() }
        })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            (resources.displayMetrics.heightPixels * 0.6).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM }
        wm.addView(root, lp)
        panel = root
    }

    private fun close() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }

    override fun onDestroy() { close(); super.onDestroy() }
}
